export default function AdminPage() {
  return (
    <div style={{ margin: 0, padding: 0, width: "100vw", height: "100vh", overflow: "auto" }}>
      <iframe 
        src="/admin-cx7k2p.html" 
        style={{ width: "100%", height: "100vh", border: "none", display: "block" }} 
      />
    </div>
  );
}
